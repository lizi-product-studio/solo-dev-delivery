"""Bounded local verification helpers."""
